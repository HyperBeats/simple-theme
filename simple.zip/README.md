# Simple

Responsive and modern theme for Azuriom built with Bootstrap.

<img src="https://cdn.discordapp.com/attachments/880144083077722142/1363588906603516135/main-page.png?ex=680694a1&is=68054321&hm=c7973796a4741b71afafc941fc397056e217261abe9e52eb7943cbc0798decd3&" width="1000">
<img src="https://cdn.discordapp.com/attachments/880144083077722142/1363588907001839636/vote-page.png?ex=680694a1&is=68054321&hm=b97bc27594f0fe65156f8682d1ee9efe87f49c0e9ee3f854a44283a995aab946&" width="1000">
